import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DiaryRoutingModule } from './diary-routing.module';
import { TodoListingComponent } from './todo-listing/todo-listing.component';
import { TodoDetailComponent } from './todo-detail/todo-detail.component';
import { TodoCreateUpdateComponent } from './todo-create-update/todo-create-update.component';
import { MaterialDesignModule } from '../material-design/material-design.module';
import { ReactiveFormsModule } from '@angular/forms';
@NgModule({
  declarations: [TodoListingComponent, TodoDetailComponent, TodoCreateUpdateComponent],
  imports: [
    CommonModule,
    MaterialDesignModule,
    ReactiveFormsModule,
    DiaryRoutingModule
  ]
})
export class DairyModule { }
