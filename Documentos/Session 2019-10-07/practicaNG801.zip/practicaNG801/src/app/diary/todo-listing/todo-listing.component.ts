import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-todo-listing',
  templateUrl: './todo-listing.component.html',
  styleUrls: ['./todo-listing.component.scss']
})
export class TodoListingComponent implements OnInit {
  sidenavActive=true;
  options: FormGroup;
  createUpdate=false;

  


  constructor(fb: FormBuilder) {
    this.options = fb.group({
      bottom: 0,
      fixed: false,
      top: 0
    });
  }

  toggleCreateUpdate(){
    this.createUpdate = ! this.createUpdate;
  }
  ngOnInit() {
  }

}
