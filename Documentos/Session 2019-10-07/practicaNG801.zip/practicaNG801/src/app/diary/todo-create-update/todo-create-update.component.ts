import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-todo-create-update',
  templateUrl: './todo-create-update.component.html',
  styleUrls: ['./todo-create-update.component.scss']
})
export class TodoCreateUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
