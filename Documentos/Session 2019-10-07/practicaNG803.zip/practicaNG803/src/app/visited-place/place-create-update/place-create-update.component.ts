import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-place-create-update',
  templateUrl: './place-create-update.component.html',
  styleUrls: ['./place-create-update.component.scss']
})
export class PlaceCreateUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
