export interface IPhone {
    description: string;
    number: string;
    countryCode: string;
}

export class Phone implements IPhone {
    description: string;
    number: string;
    countryCode: string;

    constructor(o?: IPhone) {
        this.description = o && o.description || '';
        this.number = o && o.number || '';
        this.countryCode = o && o.countryCode || '';
    }

}
