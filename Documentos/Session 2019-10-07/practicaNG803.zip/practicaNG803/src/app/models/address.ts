export interface IAddress {
    streetType: string;
    streetName: string;
    streetNumber: string;
    zipcode: string;
    city: string;
    state: string;
    country: string;
}
export class Address implements IAddress {
    streetType: string;
    streetName: string;
    streetNumber: string;
    zipcode: string;
    city: string;
    state: string;
    country: string;

    constructor(o?: IAddress){
        this.streetType = o && o.streetType || 'Av.';
        this.streetName = o && o.streetName || 'Puerto';
        this.streetNumber = o && o.streetNumber || 'S/N';
        this.zipcode = o && o.zipcode || '46001';
        this.city = o && o.city || 'València';
        this.state = o && o.state || 'Valencia';
        this.country = o && o.country || 'Spain';
    }
}
