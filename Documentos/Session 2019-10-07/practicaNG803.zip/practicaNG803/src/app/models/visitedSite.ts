export interface IVisitedSite {
    id?: string;
    name: string;
    x: string;
    y: string;
    description: string;
    year: number;
    country: string;
    city: string;
    startDate: Date;
    endDate: Date;
}
export class VisitedSite implements IVisitedSite {

    id: string;
    name: string;
    x: string;
    y: string;
    description: string;
    year: number;
    country: string;
    city: string;
    startDate: Date;
    endDate: Date;

    constructor(o?: IVisitedSite) {
        this.id = o && o.id || undefined;
        this.name = o && o.name || 'name';
        this.x = o && o.x || 'x';
        this.y = o && o.y || 'y';
        this.description = o && o.description || 'description';
        this.year = o && o.year || 1996;
        this.country = o && o.country || 'country';
        this.city = o && o.city || 'city';
        this.startDate = o && o.startDate || new Date(1990, 1, 1);
        this.endDate = o && o.endDate || new Date(1990, 1, 1);
    }
}
