import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  
  isLoggedIn$: Observable<boolean>;                  // {1}

  constructor(private _authService: AuthService) { }

  ngOnInit() {
    this.isLoggedIn$ = this._authService.isLoggedIn; // {2}
  }

}
