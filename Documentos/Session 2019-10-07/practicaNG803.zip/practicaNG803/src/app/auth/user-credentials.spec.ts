import { UserCredentials } from './user-credentials';

describe('UserCredentials', () => {
  it('should create an instance', () => {
    expect(new UserCredentials()).toBeTruthy();
  });
});
