export interface IUserCredentials {
    userName: string;
    password: string;
}
