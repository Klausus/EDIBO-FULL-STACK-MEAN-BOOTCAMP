import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PrincipalComponent } from './principal/principal.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { AboutComponent } from './about/about.component';
import { AuthGuard } from './auth/auth.guard';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  { path: '', redirectTo: 'principal', pathMatch: 'full', canActivate: [AuthGuard] },
  { path: 'login', component: LoginComponent },
  { path: 'principal', component: PrincipalComponent, canActivate: [AuthGuard]},
  { path: 'about', component: AboutComponent },
  { path: 'diary', loadChildren: () => import(`./diary/diary.module`).then(m => m.DairyModule) , canActivate: [AuthGuard]},
  { path: 'studentManagement', loadChildren: './student/student.module#StudentModule', canActivate: [AuthGuard]},
  { path: 'visitedPlaceManagement', loadChildren: () => import(`./visited-place/visited-place.module`).then(m => m.VisitedPlaceModule) , canActivate: [AuthGuard]},
  { path: '**', component: NotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
