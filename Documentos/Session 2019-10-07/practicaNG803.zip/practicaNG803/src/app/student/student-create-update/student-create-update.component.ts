import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-create-update',
  templateUrl: './student-create-update.component.html',
  styleUrls: ['./student-create-update.component.scss']
})
export class StudentCreateUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
