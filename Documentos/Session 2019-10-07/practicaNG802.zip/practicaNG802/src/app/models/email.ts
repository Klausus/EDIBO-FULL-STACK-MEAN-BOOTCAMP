export interface IEmail {
    description: string;
    email: string;
}

export class Email implements IEmail {
    description: string;
    email: string;

    constructor(o?: IEmail){
        this.description = o && o.description || '';
        this.email = 0 && o.email || '';
    }
}
