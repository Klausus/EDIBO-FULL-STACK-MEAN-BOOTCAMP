import { Address } from './address';
import { Mobile } from './mobile';
import { Phone } from './phone';

export interface IStudent {
    username: string;
    password: string;
    dni: string;
    dniLetter: string;
    firstName: string;
    middleName?: string;
    lastName: string;
    lastNameOptional?: string;
    address: Address;
    emails: Array<Mobile>;
    phones: Array<Phone>;
}

export class Student implements IStudent {
    username: string;
    password: string;
    dni: string;
    dniLetter: string;
    firstName: string;
    middleName: string;
    lastName: string;
    lastNameOptional: string;
    address: Address;
    emails: Array<Mobile>;
    phones: Array<Phone>;

    constructor(u?: IStudent) {
        this.username = u && u.username || '';
        this.password = u && u.username || '';
        this.dni = u && u.username || '';
        this.dniLetter = u && u.username || '';
        this.firstName = u && u.username || '';
        this.middleName = u && u.username || '';
        this.lastName = u && u.username || '';
        this.lastNameOptional = u && u.username || '';
        this.address.streetType = u && u.address && u.address.streetType || '';
        this.address.streetName = u && u.address && u.address.streetName || '';
        this.address.streetNumber = u && u.address && u.address.streetNumber || '';
        this.address.zipcode = u && u.address && u.address.zipcode || '';
        this.address.city = u && u.address && u.address.city || '';
        this.address.state = u && u.address && u.address.state || '';
        this.address.country = u && u.address && u.address.country || '';

        this.emails = new Array();
        for (const email of (u && u.emails) ) {
            this.emails.push( Object.assign({}, email));
        }

        this.phones = new Array();
        for (const phone of (u && u.phones) ) {
            this.phones.push( Object.assign({}, phone));
        }
    }
}
