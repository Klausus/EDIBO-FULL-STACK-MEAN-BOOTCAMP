export interface ITodo {
    id?: string;
    title: string;
    description: string;
    isCompleted: boolean;
}
export class Todo implements ITodo {
    id?: string;
    title: string;
    description: string;
    isCompleted: boolean;
    index?: number;

    constructor(o?: ITodo) {
        this.id = o && o.id || undefined;
        this.title = o && o.title || 'Title';
        this.description = o && o.description || 'Description';
        this.isCompleted = o && o.isCompleted || false;
    }
}
