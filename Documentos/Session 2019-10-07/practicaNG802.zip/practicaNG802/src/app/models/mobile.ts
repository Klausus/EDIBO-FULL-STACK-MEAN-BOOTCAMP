export interface IMobile {
    description: string;
    number: string;
}

export class Mobile implements IMobile {
    description: string;
    number: string;

    constructor(o?: IMobile){
        this.description = o && o.description || '';
        this.number = o && o.number || '';
    }
}