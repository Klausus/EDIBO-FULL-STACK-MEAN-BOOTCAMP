import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TodoListingComponent } from './todo-listing/todo-listing.component';


const routes: Routes = [
  { path: '',  redirectTo: 'todoListing', pathMatch: 'full'},
  { path: 'todoListing', component: TodoListingComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DiaryRoutingModule { }
