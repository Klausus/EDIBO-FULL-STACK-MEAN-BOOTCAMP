import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Todo } from 'src/app/models/todo';

@Component({
  selector: 'app-todo-detail',
  templateUrl: './todo-detail.component.html',
  styleUrls: ['./todo-detail.component.scss']
})
export class TodoDetailComponent implements OnInit {
  @Input()
  myTodo:Todo;
  @Input()
  myIndex:number;

  @Output()
  eventUpdateTodo = new EventEmitter<string>();
  
  constructor() { }

  ngOnInit() {
  }
  
  sendEventUpdateTodo(){
    this.eventUpdateTodo.emit(`{"index": ${this.myIndex} }`);
  }
  get date(): string {
    const fecha = new Date().toLocaleString();
    console.log(fecha);
    return fecha;
  }
}
