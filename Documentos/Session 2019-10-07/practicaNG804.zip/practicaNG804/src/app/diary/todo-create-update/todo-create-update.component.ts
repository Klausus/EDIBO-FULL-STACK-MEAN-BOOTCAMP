import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { DiaryService } from 'src/app/services/diary.service';

@Component({
  selector: 'app-todo-create-update',
  templateUrl: './todo-create-update.component.html',
  styleUrls: ['./todo-create-update.component.scss']
})
export class TodoCreateUpdateComponent implements OnInit {

  ngOnInit(): void {
    if(this.myTodo !== undefined){
      this.todoForm.patchValue({
        id: this.myTodo.id,
        title: this.myTodo.title,
        description: this.myTodo.description,
        isCompleted: this.myTodo.isCompleted
      });
    }
  }
  todoForm: FormGroup;
  
  @Input()
  myTodo;
  @Input()
  myIndex;

  @Output()
  eventCreateUpdateTodo = new EventEmitter<string>();
  
  constructor(private _fb: FormBuilder) {
    this.createTodoForm();
   }

   createTodoForm(){
    this.todoForm = this._fb.group({
      id: undefined,
       title: [''],
       description: [''],
       isCompleted:[false]
     });
   }
  onSubmit(){
    let aux = Object.assign({}, this.todoForm.value);
    if(this.myIndex === undefined ){
      aux.index=undefined;
    }
    else{
      aux.index=this.myIndex;
    }
    this.eventCreateUpdateTodo.emit(JSON.stringify(aux));
  }
}
