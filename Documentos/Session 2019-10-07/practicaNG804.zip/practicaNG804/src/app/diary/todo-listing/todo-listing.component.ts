import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Todo } from 'src/app/models/todo';
import { DiaryService } from 'src/app/services/diary.service';

@Component({
  selector: 'app-todo-listing',
  templateUrl: './todo-listing.component.html',
  styleUrls: ['./todo-listing.component.scss']
})
export class TodoListingComponent implements OnInit {
  sidenavActive=true;
  todoForm: FormGroup;
  createUpdate=false;
  selectedTodo: Todo = undefined;
  selectedIndex:number = undefined;

  DiaryList: Array<Todo> = [
    { id: '1111', title:'Todo 1', description: 'description Todo 1', isCompleted: false},
    { id: '2222', title:'Todo 2', description: 'description Todo 2', isCompleted: false},
    { id: '3333', title:'Todo 3', description: 'description Todo 3', isCompleted: false},
    { id: '4444', title:'Todo 4', description: 'description Todo 4', isCompleted: false},
    { id: '5555', title:'Todo 5', description: 'description Todo 5', isCompleted: false},
    { id: '6666', title:'Todo 6', description: 'description Todo 6', isCompleted: false},
    { id: '7777', title:'Todo 7', description: 'description Todo 7', isCompleted: false},
    { id: '8888', title:'Todo 8', description: 'description Todo 8', isCompleted: false},
    { id: '9999', title:'Todo 9', description: 'description Todo 9', isCompleted: false},
  ]

  constructor(private fb: FormBuilder, private _dairyService: DiaryService) {
    this.todoForm = fb.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
      isCompleted: false
    });
    this.selectedIndex = undefined;
    this.selectedTodo = undefined;
  }

  toggleCreateUpdate(){
    this.createUpdate = ! this.createUpdate;
  }

  ngOnInit() {
    this._dairyService.getTodoList().subscribe((respuesta: any) => {
      console.log(respuesta);
      console.log('datos del servidor');
      this.DiaryList = respuesta;
    }, error=>{
      console.log(error);
    })
  }

  setSelectedValues(todo:Todo, indice:number){
    this.selectedIndex = indice;
    this.selectedTodo = todo;
    this.createUpdate = false;
  }

  processCreateUpdateTodo(todo){
    let auxTodo = JSON.parse(todo);
    if( auxTodo.index === undefined ){
      console.log('crear');
      delete(auxTodo['index']);
      this._dairyService.createTodo(auxTodo).subscribe((respuesta) => {
        this.DiaryList.push(respuesta);
        this.selectedIndex = this.DiaryList.length-1;
        this.selectedTodo =  this.DiaryList[this.selectedIndex];
        this.createUpdate = false;
      })
      
    }
    else{
      const indice = auxTodo.index;
      delete(auxTodo.index);
      this._dairyService.updateTodo(todo).subscribe(() => {
        this.DiaryList[indice] = auxTodo;
        this.selectedTodo=auxTodo;
      }, (error:any) => {
        console.log(error);
      })

    }
    this.createUpdate = false;
  }

  deleteTodo(todo: Todo, index: number) {
    console.log(todo.id);
    
    this._dairyService.deleteTodoByID(todo.id).subscribe( () => {
      this.selectedIndex = undefined;
      this.selectedTodo = undefined;
      this.createUpdate = false;
      this.DiaryList.splice(index, 1);
    });
  }

  prepareUpdateDirect(todo:Todo, indice:number){
    this.createUpdate=true;
    let auxTodo = Object.assign({}, todo);
    auxTodo.index = indice;
    this.selectedTodo = auxTodo;
  }
  
  prepareUpdate(){
    this.createUpdate=true;
    let auxTodo = Object.assign({}, this.selectedTodo);
    auxTodo.index = this.selectedIndex;
    console.log(auxTodo);
    this.selectedTodo = auxTodo;
  }

  prepareCreate(){
    this.createUpdate=true;
    let auxTodo = new Todo();
    auxTodo.index = undefined;
    this.selectedTodo = auxTodo;
  }
  get date(): string {
    const fecha = new Date().toLocaleString();
    console.log(fecha);
    return fecha;
  }
  showNewTodoForm(){
    this.selectedTodo = undefined;
    this.selectedIndex = undefined;
    this.createUpdate = true;
  }


}
