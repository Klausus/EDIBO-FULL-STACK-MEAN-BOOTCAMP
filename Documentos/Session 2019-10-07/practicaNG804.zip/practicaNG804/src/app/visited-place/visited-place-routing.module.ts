import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PlaceListingComponent } from './place-listing/place-listing.component';


const routes: Routes = [
  { path:'', redirectTo: 'visitedPlacesListing', pathMatch: 'full'},
  { path: 'visitedPlacesListing', component: PlaceListingComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VisitedPlaceRoutingModule { }
