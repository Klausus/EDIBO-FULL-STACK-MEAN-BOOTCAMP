import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-place-detail',
  templateUrl: './place-detail.component.html',
  styleUrls: ['./place-detail.component.scss']
})
export class PlaceDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
