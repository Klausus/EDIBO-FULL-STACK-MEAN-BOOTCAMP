import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-place-listing',
  templateUrl: './place-listing.component.html',
  styleUrls: ['./place-listing.component.scss']
})
export class PlaceListingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
