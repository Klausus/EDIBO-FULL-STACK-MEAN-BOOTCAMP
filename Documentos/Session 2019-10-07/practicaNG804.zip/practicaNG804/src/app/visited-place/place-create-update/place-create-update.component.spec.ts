import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaceCreateUpdateComponent } from './place-create-update.component';

describe('PlaceCreateUpdateComponent', () => {
  let component: PlaceCreateUpdateComponent;
  let fixture: ComponentFixture<PlaceCreateUpdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlaceCreateUpdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaceCreateUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
