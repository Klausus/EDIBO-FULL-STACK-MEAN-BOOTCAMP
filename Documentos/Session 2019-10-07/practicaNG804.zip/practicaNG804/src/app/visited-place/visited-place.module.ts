import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VisitedPlaceRoutingModule } from './visited-place-routing.module';
import { PlaceListingComponent } from './place-listing/place-listing.component';
import { PlaceDetailComponent } from './place-detail/place-detail.component';
import { PlaceCreateUpdateComponent } from './place-create-update/place-create-update.component';


@NgModule({
  declarations: [PlaceListingComponent, PlaceDetailComponent, PlaceCreateUpdateComponent],
  imports: [
    CommonModule,
    VisitedPlaceRoutingModule
  ]
})
export class VisitedPlaceModule { }
