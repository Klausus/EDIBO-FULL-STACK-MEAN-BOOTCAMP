import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StudentRoutingModule } from './student-routing.module';
import { StudentListingComponent } from './student-listing/student-listing.component';
import { StudentDetailComponent } from './student-detail/student-detail.component';
import { StudentCreateUpdateComponent } from './student-create-update/student-create-update.component';


@NgModule({
  declarations: [StudentListingComponent, StudentDetailComponent, StudentCreateUpdateComponent],
  imports: [
    CommonModule,
    StudentRoutingModule
  ]
})
export class StudentModule { }
