import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-listing',
  templateUrl: './student-listing.component.html',
  styleUrls: ['./student-listing.component.scss']
})
export class StudentListingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
