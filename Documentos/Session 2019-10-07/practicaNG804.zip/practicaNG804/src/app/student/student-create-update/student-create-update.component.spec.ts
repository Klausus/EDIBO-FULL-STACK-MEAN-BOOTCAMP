import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentCreateUpdateComponent } from './student-create-update.component';

describe('StudentCreateUpdateComponent', () => {
  let component: StudentCreateUpdateComponent;
  let fixture: ComponentFixture<StudentCreateUpdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StudentCreateUpdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentCreateUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
