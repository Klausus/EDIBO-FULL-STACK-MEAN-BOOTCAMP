import { TestBed } from '@angular/core/testing';

import { VisitedPlaceService } from './visited-place.service';

describe('VisitedPlaceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: VisitedPlaceService = TestBed.get(VisitedPlaceService);
    expect(service).toBeTruthy();
  });
});
