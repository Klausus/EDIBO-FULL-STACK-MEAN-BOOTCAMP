import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Todo } from '../models/todo';

@Injectable({
    providedIn: 'root'
})
export class DiaryService {
    readAllTodosURL = "http://localhost:3100/diary/todos/readAll";
    readTodoByIDURL = "http://localhost:3100/diary/todo/read";
    createTodoURL = "http://localhost:3100/diary/todo/create";
    deleteTodoURL = "http://localhost:3100/diary/todo/delete/";

    httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json'
        })
    };

    constructor(private http: HttpClient) {}

    getTodoList(): Observable<any> {
        console.log(this.readAllTodosURL);
        return this.http.get(this.readAllTodosURL, this.httpOptions);
    }
    deleteTodoByID(id:string): Observable<any>{
        return this.http.delete('http://localhost:3100/diary/todo/delete/'+id, this.httpOptions);
    }
    createTodo(todo: Todo): Observable<any>{
        return this.http.post('http://localhost:3100/diary/todo/create', todo , this.httpOptions)
    }
    updateTodo(todo):Observable<any>{
        const miObjeto = JSON.parse(todo);
        delete(miObjeto['index']);
        return this.http.patch('http://localhost:3100/diary/'+miObjeto.id, JSON.stringify(miObjeto) , this.httpOptions);
    }
}
