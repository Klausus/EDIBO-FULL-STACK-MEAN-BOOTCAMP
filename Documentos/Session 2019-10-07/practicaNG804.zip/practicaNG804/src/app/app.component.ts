import { Component } from '@angular/core';
import { DiaryService } from './services/diary.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'practicaNG804';
  constructor(private _diaryService: DiaryService){}

  getAllTodos(){
    this._diaryService.getTodoList();
  }
}
